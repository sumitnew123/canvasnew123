
var headertext = [],
headers = document.querySelectorAll(".tbl-craftmen th"),
tablerows = document.querySelectorAll(".tbl-craftmen th"),
tablebody = document.querySelector(".tbl-craftmen tbody");

for(var i = 0; i < headers.length; i++) {
  var current = headers[i];
  headertext.push(current.textContent.replace(/\r?\n|\r/,""));
} 
for (var i = 0, row; row = tablebody.rows[i]; i++) {
  for (var j = 0, col; col = row.cells[j]; j++) {
    col.setAttribute("data-th", headertext[j]);
  } 
}
$(document).ready(function(){

	$('.level-1').click(function(){
		//$(".tbl-craftmen .level-2").hide();
		$(this).parents('tr').addClass('myclass');
		//$(".tbl-craftmen .level-2").hide();
		$(".myclass").next('.level-2').slideToggle();
		
		$(this).parents('tr').removeClass('myclass');
	});

});